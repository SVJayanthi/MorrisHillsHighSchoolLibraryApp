package com.example.sravan.applibrary;

import android.annotation.SuppressLint;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.internal.BottomNavigationMenuView;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sravan.applibrary.objects.Book;
import com.example.sravan.applibrary.objects.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

//Displays list of books based off user search request
public class BooksSearch extends AppCompatActivity
        implements BooksListAdapter.ListItemClickListener{

    //Instantiate objects
    private FirebaseDatabase mDatabase;
    private FirebaseAuth mAuth;
    private DatabaseReference mUserDatabaseReference;
    private DatabaseReference mBooksDatabaseReference;


    private BooksListAdapter mAdapterBooksDisplay;
    private RecyclerView mBooksDisplay;
    private BooksListAdapter mAdapterBooksDisplayO;
    private RecyclerView mBooksDisplayO;
    private TextView mDisplayResults;

    private String searchExtra;
    private int userGrade;
    private String userId;

    private Toast mToast;
    private final static String TAG = BooksSearch.class.getSimpleName();

    //Get references for each of the objects
    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_books_search);

        searchExtra = getIntent().getStringExtra("query");
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();


        mBooksDatabaseReference = mDatabase.getReference().child("Library");


        mBooksDisplay = (RecyclerView) findViewById(R.id.display_books_search);
        mBooksDisplayO = (RecyclerView) findViewById(R.id.display_books_other);
        mDisplayResults = (TextView) findViewById(R.id.display_results);


        GridLayoutManager layoutManagerBooksDisplay = new GridLayoutManager(this, 2);
        mBooksDisplay.setLayoutManager(layoutManagerBooksDisplay);

        GridLayoutManager layoutManagerBooksDisplayO = new GridLayoutManager(this, 2);
        mBooksDisplayO.setLayoutManager(layoutManagerBooksDisplayO);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setSelectedItemId(R.id.navigation_books);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        BottomNavigationMenuView menuView = (BottomNavigationMenuView) navigation.getChildAt(0);
        for (int i = 0; i < menuView.getChildCount(); i++) {
            BottomNavigationItemView itemView = (BottomNavigationItemView) menuView.getChildAt(i);
            itemView.setShiftingMode(false);
            itemView.setChecked(false);
        }

    }

    @Override
    public void onStart() {
        super.onStart();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        userId = currentUser.getUid();
        mUserDatabaseReference = mDatabase.getReference().child("Users").child(userId);

        //Get user grade to conduct search queries
        mUserDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                User currentUser = dataSnapshot.getValue(User.class);

                userGrade = currentUser.getGrade();
                setBooksAdapter();

                Log.d(TAG, "User is: " + currentUser);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w(TAG, "Failed to read value.");

            }
        });
    }



    private List<Book> mBooks = new ArrayList<>();
    private List<Book> mBooksO = new ArrayList<>();
    private int count = 0;


    private void setBooksAdapter() {
        mBooks.clear();

        int higherGrade;
        if (userGrade > 11) {
            higherGrade = 11;
        } else {
            higherGrade = userGrade + 1;
        }

        String search = searchExtra.toLowerCase();
        mBooksDatabaseReference.orderByChild("title").startAt(search).endAt(search + "\uf8ff").limitToFirst(2).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                Book book = dataSnapshot.getValue(Book.class);

                mBooks.add(book);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mBooksDatabaseReference.orderByChild("author").startAt(search).endAt(search + "\uf8ff").limitToFirst(2).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                Book book = dataSnapshot.getValue(Book.class);

                mBooks.add(book);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        mBooksDatabaseReference.orderByChild("title").startAt(search).limitToFirst(2).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                Book book = dataSnapshot.getValue(Book.class);

                mBooks.add(book);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        mBooksDatabaseReference.orderByChild("title").endAt(search).limitToLast(2).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                Book book = dataSnapshot.getValue(Book.class);

                mBooks.add(book);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mBooksDatabaseReference.orderByChild("author").startAt(search).limitToFirst(2).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                Book book = dataSnapshot.getValue(Book.class);

                mBooks.add(book);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        mBooksDatabaseReference.orderByChild("author").endAt(search).limitToLast(2).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                Book book = dataSnapshot.getValue(Book.class);

                mBooks.add(book);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mBooksDatabaseReference.orderByChild("targetGrade").startAt(userGrade).endAt(higherGrade).limitToFirst(6).
                addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                        Log.d(TAG, "onChildAdded:" + dataSnapshot.getKey());

                        Book book = dataSnapshot.getValue(Book.class);

                        mBooksO.add(book);

                        count++;
                        if (count > 5) {
                            setBookAdapter();
                            count = 0;
                            return;
                        }
                    }

                    @Override
                    public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onChildRemoved(DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
    }

    //Set adapter for the book display
    private void setBookAdapter() {

        mDisplayResults.setText("\""+ searchExtra + "\"" + " results:");

        //Set the display adapter for the Recycler View, will also query from server
        mAdapterBooksDisplay = new BooksListAdapter(this, this, mBooks, mBooks.size());
        mBooksDisplay.setAdapter(mAdapterBooksDisplay);

        mAdapterBooksDisplayO = new BooksListAdapter(this, this, mBooksO, mBooksO.size());
        mBooksDisplayO.setAdapter(mAdapterBooksDisplayO);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    Intent sendMain = new Intent(BooksSearch.this, MainActivity.class);
                    startActivity(sendMain);

                    return true;
                case R.id.navigation_books:
                    Intent sendBooks = new Intent(BooksSearch.this, BooksActivity.class);
                    startActivity(sendBooks);

                    return true;
                case R.id.navigation_maps:
                    Intent sendMap = new Intent(BooksSearch.this, MapsActivity.class);
                    startActivity(sendMap);

                    return true;
                case R.id.navigation_calendar:
                    Intent sendCalendar = new Intent(BooksSearch.this, CalendarActivity.class);
                    startActivity(sendCalendar);


                    return true;
                case R.id.navigation_backpack:
                    Intent sendBag = new Intent(BooksSearch.this, BackpackActivity.class);
                    startActivity(sendBag);

                    return true;
            }
            return false;
        }
    };

    @Override
    public void onListItemClick(String clickedBook) {

        Intent intent = new Intent(BooksSearch.this, BooksDetail.class);
        intent.putExtra("Identification", clickedBook);


        if (mToast != null) {
            mToast.cancel();
        }

        String toastMessage = "Item " + clickedBook + " clicked.";
        mToast = Toast.makeText(this, toastMessage, Toast.LENGTH_LONG);
        mToast.show();

        startActivity(intent);

    }
}