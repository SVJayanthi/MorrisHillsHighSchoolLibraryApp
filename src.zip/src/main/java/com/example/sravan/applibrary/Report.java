package com.example.sravan.applibrary;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by Sravan on 1/18/2018.
 */

//Allow user to send report about the app and any possible bugs it may contain
public class Report extends AppCompatActivity {


    private DatabaseReference mDatabase;
    private FirebaseAuth mAuth;

    private EditText mReport;

    private Button mSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        mReport = (EditText) findViewById(R.id.report_edit);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        mSubmit = (Button) findViewById(R.id.submit);

        //Information submitted by user will be stored on the server database
        mSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference mReportChild = mDatabase.child("Report").push();

                String key = mReportChild.getKey();

                String response = mReport.getText().toString();

                mDatabase.child("Report").child(key).child("Info").setValue(response);

            }
        });
    }

}
